﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RoomLibrary
{
    public class Room
    {
        double roomLength;
        double roomWidth;
        public double RoomLength
        {
            get { return roomLength; }
            set { roomLength = value; }
        }
        public double RoomPerimeter()
        {
            return 2 * (roomLength + roomWidth);
        }

        public double RoomArea()
        {
            return roomLength * roomWidth;

        }
    
    /// Метод вычисляет число квадратных метров /// на одного человека
    /// </summary>
    /// <param name = "np"›Число человек</param>
    /// <returns>Возвращает число квадратных метров‹/returns>
        public double PersonArea(int np)
        {
        return RoomArea() / np;

        }
    }
}
